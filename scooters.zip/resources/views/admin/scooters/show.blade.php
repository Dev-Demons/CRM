@extends('layouts.admin')
@section('content')
<div class="main-card">
    <div class="header">
        {{ trans('global.show') }} {{ trans('cruds.scooter.title') }}
    </div>

    <div class="body">
        <div class="block pb-4">
            <a class="btn-md btn-gray" href="{{ url()->previous() }}">
                {{ trans('global.back_to_list') }}
            </a>
        </div>
        <!-- <div class="bg-white p-3" id="print_div">
            <div class="flex flex-shrink-0 items-center justify-center mt-2">
                <img class="responsive" src="{{ asset('img/logo_big.png') }}" alt="logo">
            </div>
            <h3 class="font-bold leading-tight text-center text-3xl mt-4 mb-2 text-black">Proces verbal pentru intrare in service</h3>
            <div class="mt-6 px-5">
                <p class="font-semibold text-black py-2">CODBARE : <span class="font-semibold">{{ $scooter->barcode }}</span></p>
                <p class="font-semibold text-black py-2">Nume / Prenume : <span class="font-semibold">{{ $scooter->name }}</span></p>
                <p class="font-semibold text-black py-2">Telefon : <span class="font-semibold">{{ $scooter->phone }}</span></p>
                <p class="font-semibold text-black py-2">Probleme : </p>
                <div class="problem border-solid border-2 border-green-500 px-4 py-2" style="min-height: 10rem;">
                    <span class="font-bold text-black">{{ $scooter->problem }}</span>
                </div>
                <p class="font-semibold text-black py-2">Rezolvat : </p>
                <div class="problem border-solid border-2 border-green-500 px-4 py-2" style="min-height: 10rem;">
                    <span class="font-bold text-black">{{ $scooter->solved }}</span>
                </div>
                <div class="mt-6">
                    <label class="inline-flex items-center">
                        <input type="checkbox" name="remember" id="remember" class="form-checkbox text-white-600 bg-blue-500">
                        <span class="mx-2 text-black font-semibold">Sunt de acord cu preluarea si prelucrarea datelor cu caracter personal conform procedurii GDPR</span>
                    </label>
                </div>
                <div class="mt-10 grid grid-cols-2 gap-4">
                    <div class="py-4">
                        <p class="font-semibold text-black py-0">DOCTORTROTINETA SRL</p>
                        <p class="font-semibold text-black py-0">0310050689 / 0723110511</p>
                        <p class="font-semibold text-black py-0"><a class="hover:no-underline text-black" href="https://www.doctortrotineta.ro" target="_new">www.doctortrotineta.ro</a></p>
                    </div>
                    <div class="py-4">
                        <p class="font-semibold text-black">DATA : <span class="font-semibold">{{ date('d.M.Y', strtotime($scooter->updated_at)) }}</span></p>
                    </div>
                </div>
            </div>
        </div> -->
        <div id="scooterItemTable">
            <table class="striped bordered show-table">
                <tbody>
                    <tr>
                        <th>
                            {{ trans('cruds.scooter.fields.id') }}
                        </th>
                        <td>
                            {{ $scooter->id }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.scooter.fields.name') }}
                        </th>
                        <td>
                            {{ $scooter->name }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.scooter.fields.phone') }}
                        </th>
                        <td>
                            {{ $scooter->phone }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.scooter.fields.barcode') }}
                        </th>
                        <td>
                            {{ $scooter->barcode }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.scooter.fields.model') }}
                        </th>
                        <td>
                            {{ $scooter->model }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.scooter.fields.problem') }}
                        </th>
                        <td>
                            {{ $scooter->problem }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.scooter.fields.solved') }}
                        </th>
                        <td>
                            {{ $scooter->solved }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.scooter.fields.price') }}
                        </th>
                        <td>
                            {{ $scooter->price ? '$' . number_format($scooter->price, 2) : '' }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.scooter.fields.solved') }}
                        </th>
                        <td>
                            {{ $scooter->solved }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.scooter.fields.created_at') }}
                        </th>
                        <td>
                            {{ $scooter->created_at }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.scooter.fields.updated_at') }}
                        </th>
                        <td>
                            {{ $scooter->updated_at }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.scooter.fields.status') }}
                        </th>
                        <td>
                            <span class="bg-blue-300 text-blue-800 text-sm font-semibold mr-2 px-1 py-0.5 rounded dark:bg-blue-200 dark:text-blue-800">{{ $scooter->status->name ?? '' }}</span>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <div class="block pt-4">
            <a class="btn-md btn-blue import_btn" href="{{ route('admin.scooter-pdf', [$scooter->id]) }}">Print PDF</a>
        </div>
    </div>
</div>
@endsection
