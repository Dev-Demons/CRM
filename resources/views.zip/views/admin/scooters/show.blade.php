@extends('layouts.admin')
@section('content')
<div class="main-card">
    <div class="header">
        {{ trans('global.show') }} {{ trans('cruds.scooter.title') }}
    </div>

    <div class="body">
        <div class="block pb-4">
            <a class="btn-md btn-gray" href="{{ url()->previous() }}">
                {{ trans('global.back_to_list') }}
            </a>
        </div>
        <table class="striped bordered show-table">
            <tbody>
                <tr>
                    <th>
                        {{ trans('cruds.scooter.fields.id') }}
                    </th>
                    <td>
                        {{ $scooter->id }}
                    </td>
                </tr>
                <tr>
                    <th>
                        {{ trans('cruds.scooter.fields.first_name') }}
                    </th>
                    <td>
                        {{ $scooter->first_name }}
                    </td>
                </tr>
                <tr>
                    <th>
                        {{ trans('cruds.scooter.fields.last_name') }}
                    </th>
                    <td>
                        {{ $scooter->last_name }}
                    </td>
                </tr>
                <tr>
                    <th>
                        {{ trans('cruds.scooter.fields.phone') }}
                    </th>
                    <td>
                        {{ $scooter->phone }}
                    </td>
                </tr>
                <tr>
                    <th>
                        {{ trans('cruds.scooter.fields.barcode') }}
                    </th>
                    <td>
                        {{ $scooter->barcode }}
                    </td>
                </tr>
                <tr>
                    <th>
                        {{ trans('cruds.scooter.fields.problem') }}
                    </th>
                    <td>
                        {{ $scooter->problem }}
                    </td>
                </tr>
                <tr>
                    <th>
                        {{ trans('cruds.scooter.fields.solved') }}
                    </th>
                    <td>
                        {{ $scooter->solved }}
                    </td>
                </tr>
                <tr>
                    <th>
                        {{ trans('cruds.scooter.fields.solved') }}
                    </th>
                    <td>
                        {{ $scooter->solved }}
                    </td>
                </tr>
                <tr>
                    <th>
                        {{ trans('cruds.scooter.fields.created_at') }}
                    </th>
                    <td>
                        {{ $scooter->created_at }}
                    </td>
                </tr>
                <tr>
                    <th>
                        {{ trans('cruds.scooter.fields.updated_at') }}
                    </th>
                    <td>
                        {{ $scooter->updated_at }}
                    </td>
                </tr>
                <tr>
                    <th>
                        {{ trans('cruds.scooter.fields.status') }}
                    </th>
                    <td>
                        <span class="bg-blue-300 text-blue-800 text-sm font-semibold mr-2 px-1 py-0.5 rounded dark:bg-blue-200 dark:text-blue-800">{{ $scooter->status->name ?? '' }}</span>
                    </td>
                </tr>
            </tbody>
        </table>
        <div class="block pt-4">
            <a class="btn-md btn-gray" href="{{ route('admin.scooters.index') }}">
                {{ trans('global.back_to_list') }}
            </a>
        </div>
    </div>
</div>
@endsection