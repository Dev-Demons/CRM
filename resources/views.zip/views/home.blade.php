@extends('layouts.admin')
@section('content')
<div class="grid grid-cols-2 gap-4">
    <div class="main-card">
        <div class="header">
            Scooter Ready List
        </div>

        <div class="body">
            <div class="w-full">
                <table class="stripe hover bordered datatable datatable-ready-scooter">
                    <thead>
                        <tr>
                            <th>
                                {{ trans('cruds.scooter.fields.barcode') }}
                            </th>
                            <th>
                                {{ trans('cruds.scooter.fields.name') }}
                            </th>
                            <th>
                                {{ trans('cruds.scooter.fields.phone') }}
                            </th>
                            <th>
                                {{ trans('global.action') }}
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($ready_scooters as $key => $scooter)
                            <tr data-entry-id="{{ $scooter->id }}">
                                <td align="center">
                                    {{ $scooter->barcode ?? '' }}
                                </td>
                                <td align="center">
                                    {{ $scooter->first_name ?? '' }} {{ $scooter->last_name ?? '' }}
                                </td>
                                <td align="center">
                                    {{ $scooter->phone ?? '' }}
                                </td>
                                <td align="center">
                                    @can('scooter_show')
                                        <a class="btn-sm btn-indigo" href="{{ route('admin.scooters.show', $scooter->id) }}">
                                            {{ trans('global.view') }}
                                        </a>
                                    @endcan

                                    @can('scooter_edit')
                                        <a class="btn-sm btn-blue" href="{{ route('admin.scooters.edit', $scooter->id) }}">
                                            {{ trans('global.edit') }}
                                        </a>
                                    @endcan

                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="main-card">
        <div class="header">
            Scooter Working List
        </div>

        <div class="body">
        <div class="w-full">
                <table class="stripe hover bordered datatable datatable-ready-scooter">
                    <thead>
                        <tr>
                            <th>
                                {{ trans('cruds.scooter.fields.barcode') }}
                            </th>
                            <th>
                                {{ trans('cruds.scooter.fields.name') }}
                            </th>
                            <th>
                                {{ trans('cruds.scooter.fields.phone') }}
                            </th>
                            <th>
                                {{ trans('global.action') }}
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($working_scooters as $key => $scooter)
                            <tr data-entry-id="{{ $scooter->id }}">
                                <td align="center">
                                    {{ $scooter->barcode ?? '' }}
                                </td>
                                <td align="center">
                                    {{ $scooter->first_name ?? '' }} {{ $scooter->last_name ?? '' }}
                                </td>
                                <td align="center">
                                    {{ $scooter->phone ?? '' }}
                                </td>
                                <td align="center">
                                    @can('scooter_show')
                                        <a class="btn-sm btn-indigo" href="{{ route('admin.scooters.show', $scooter->id) }}">
                                            {{ trans('global.view') }}
                                        </a>
                                    @endcan

                                    @can('scooter_edit')
                                        <a class="btn-sm btn-blue" href="{{ route('admin.scooters.edit', $scooter->id) }}">
                                            {{ trans('global.edit') }}
                                        </a>
                                    @endcan

                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

@endsection
@section('scripts')
@parent
<script>
    $(function () {
        $('.datatable-ready-scooter').DataTable();
    });

</script>
@endsection